"""
CUDA FPS: CUDA-accelerated Farthest Point Sampling for PyTorch

This package provides efficient GPU-accelerated implementation of Farthest Point
Sampling (FPS) algorithm for point clouds.
"""

from .fps import fps, fps_batched

__version__ = '0.1.0'
__all__ = ['fps', 'fps_batched']
