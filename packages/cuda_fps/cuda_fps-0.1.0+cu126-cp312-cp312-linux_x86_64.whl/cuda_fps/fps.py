import torch
from typing import Optional

try:
    import cuda_fps_backend
except ImportError:
    cuda_fps_backend = None
    import warnings
    warnings.warn("cuda_fps_backend not found. Please install the package with: pip install .")


def fps(
    points: torch.Tensor,
    offsets: torch.Tensor,
    num_sampled_points: int,
    start_idx: Optional[torch.Tensor] = None,
    distance_dim: Optional[int] = None
) -> torch.Tensor:
    """
    Farthest Point Sampling (FPS) for segmented point clouds.

    Args:
        points (torch.Tensor): Input point cloud of shape (N, D) where N is total number
                              of points across all segments and D is the dimensionality.
        offsets (torch.Tensor): Segment boundaries of shape (K+1,) where K is the number
                               of segments. offsets[i] indicates the starting index of
                               segment i, and offsets[-1] should equal N.
        num_sampled_points (int): Number of points to sample from each segment.
        start_idx (Optional[torch.Tensor]): Starting point index for each segment,
                                           shape (K,). If None, starts with the first
                                           point (index 0) in each segment. Default: None.
        distance_dim (Optional[int]): Number of dimensions to use for distance computation.
                                     If None, uses all D dimensions. This allows computing
                                     distances on a subset of features (e.g., xyz only) while
                                     keeping all features in the output. Default: None.

    Returns:
        torch.Tensor: Sampled points of shape (num_sampled_points * K, D). If a segment
                     has fewer than num_sampled_points, the remaining slots are zero-padded.

    Example:
        >>> # GPU example
        >>> points = torch.randn(1000, 3, device='cuda')
        >>> offsets = torch.tensor([0, 300, 700, 1000], dtype=torch.int32, device='cuda')
        >>> sampled = fps(points, offsets, num_sampled_points=100)
        >>> sampled.shape
        torch.Size([300, 3])  # 100 points * 3 segments

        >>> # CPU example
        >>> points = torch.randn(1000, 3)
        >>> offsets = torch.tensor([0, 1000], dtype=torch.int32)
        >>> sampled = fps(points, offsets, num_sampled_points=100)
        >>> sampled.shape
        torch.Size([100, 3])

        >>> # Using distance_dim with 6D points (xyz + rgb)
        >>> points = torch.randn(1000, 6, device='cuda')  # xyz + rgb
        >>> sampled = fps(points, offsets, num_sampled_points=100, distance_dim=3)
        >>> sampled.shape
        torch.Size([300, 6])  # distances computed on xyz, but all 6 features retained
    """
    if cuda_fps_backend is None:
        raise RuntimeError("cuda_fps_backend not available. Please install the package.")

    # Check that points and offsets are on the same device
    if points.device != offsets.device:
        raise ValueError(f"points and offsets must be on the same device, got {points.device} and {offsets.device}")

    if points.dim() != 2:
        raise ValueError(f"points must be 2D (N, D), got shape {points.shape}")

    if offsets.dim() != 1:
        raise ValueError(f"offsets must be 1D (K+1,), got shape {offsets.shape}")

    if points.dtype != torch.float32:
        points = points.float()

    if offsets.dtype != torch.int32:
        offsets = offsets.int()

    if start_idx is not None:
        if start_idx.device != points.device:
            raise ValueError(f"start_idx must be on the same device as points, got {start_idx.device} and {points.device}")
        if start_idx.dim() != 1:
            raise ValueError(f"start_idx must be 1D (K,), got shape {start_idx.shape}")
        if start_idx.dtype != torch.int32:
            start_idx = start_idx.int()
        if start_idx.size(0) != offsets.size(0) - 1:
            raise ValueError(f"start_idx length {start_idx.size(0)} must equal K (offsets.size(0) - 1 = {offsets.size(0) - 1})")
    else:
        start_idx = torch.empty(0, dtype=torch.int32, device=points.device)

    # Default to using all dimensions if distance_dim is not specified
    if distance_dim is None:
        distance_dim = -1  # Backend will set this to D

    if distance_dim != -1:
        if distance_dim <= 0 or distance_dim > points.size(1):
            raise ValueError(f"distance_dim must be positive and <= D={points.size(1)}, got {distance_dim}")

    return cuda_fps_backend.fps_forward(points, offsets, num_sampled_points, start_idx, distance_dim)


def fps_batched(
    points: torch.Tensor,
    num_sampled_points: int,
    start_idx: Optional[torch.Tensor] = None,
    distance_dim: Optional[int] = None
) -> torch.Tensor:
    """
    Batched Farthest Point Sampling (FPS) for batched point clouds.

    This is a convenience wrapper around fps() that handles batched inputs by
    internally creating the appropriate offsets.

    Args:
        points (torch.Tensor): Batched point cloud of shape (B, M, D) where B is batch size,
                              M is the number of points per batch, and D is dimensionality.
        num_sampled_points (int): Number of points to sample from each batch element.
        start_idx (Optional[torch.Tensor]): Starting point index for each batch element,
                                           shape (B,). If None, starts with the first point
                                           (index 0) in each batch. Default: None.
        distance_dim (Optional[int]): Number of dimensions to use for distance computation.
                                     If None, uses all D dimensions. This allows computing
                                     distances on a subset of features (e.g., xyz only) while
                                     keeping all features in the output. Default: None.

    Returns:
        torch.Tensor: Sampled points of shape (B, num_sampled_points, D). If M < num_sampled_points,
                     the remaining slots are zero-padded.

    Example:
        >>> points = torch.randn(32, 1024, 3, device='cuda')
        >>> sampled = fps_batched(points, num_sampled_points=256)
        >>> sampled.shape
        torch.Size([32, 256, 3])

        >>> # Using distance_dim with 6D points (xyz + rgb)
        >>> points = torch.randn(32, 1024, 6, device='cuda')  # xyz + rgb
        >>> sampled = fps_batched(points, num_sampled_points=256, distance_dim=3)
        >>> sampled.shape
        torch.Size([32, 256, 6])  # distances computed on xyz, but all 6 features retained
    """
    if points.dim() != 3:
        raise ValueError(f"points must be 3D (B, M, D), got shape {points.shape}")

    B, M, D = points.shape

    # Reshape to (B*M, D)
    points_flat = points.reshape(B * M, D)

    # Create offsets: [0, M, 2*M, ..., B*M]
    offsets = torch.arange(0, B + 1, dtype=torch.int32, device=points.device) * M

    # Handle start_idx
    if start_idx is not None:
        if start_idx.device != points.device:
            raise ValueError(f"start_idx must be on the same device as points, got {start_idx.device} and {points.device}")
        if start_idx.dim() != 1:
            raise ValueError(f"start_idx must be 1D (B,), got shape {start_idx.shape}")
        if start_idx.size(0) != B:
            raise ValueError(f"start_idx length {start_idx.size(0)} must equal batch size {B}")
        if start_idx.dtype != torch.int32:
            start_idx = start_idx.int()

    # Call fps
    sampled_flat = fps(points_flat, offsets, num_sampled_points, start_idx, distance_dim)

    # Reshape to (B, num_sampled_points, D)
    sampled = sampled_flat.reshape(B, num_sampled_points, D)

    return sampled
